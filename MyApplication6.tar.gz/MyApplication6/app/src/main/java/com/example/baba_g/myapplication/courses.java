package com.example.baba_g.myapplication;

/**
 * Created by rahul on 22/2/16.
 */
public class courses {


        public String code;

        public String name;



        public courses(String name, String code) {

            this.name = name;

            this.code = code;

        }


}
